import json, glob
from pathlib import Path
import pandas as pd
import numpy as np

# Ensure repo root is importable
import sys, pathlib as _pl
ROOT = _pl.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.io_ohlcv import read_any_ohlcv
from src.atr_basic import atr
from src.engine.footprint import ticks_to_microbars, attach_minute_ATR60_to_micro
from src.engine.absorption import AbsorptionCfg, absorption_events
from src.utils import donchian_high, donchian_low

# -------------- Tick discovery + loader --------------
import os, glob as _glob

# Progress helper
try:
    from tqdm.auto import tqdm  # type: ignore
except Exception:  # pragma: no cover
    def tqdm(it, total=None, desc=None):
        it = list(it)
        n = len(it) if total is None else total
        print(f"{desc or 'Progress'}: 0/{n}", end="\r")
        for i, x in enumerate(it, 1):
            if i % max(1, n // 10 or 1) == 0:
                print(f"{desc or 'Progress'}: {i}/{n}", end="\r")
            yield x
        print(f"{desc or 'Progress'}: {n}/{n}")

TICK_COL_OPTS = [
    ("ts","timestamp","time","date","open_time","open_time_ms","ts_ms"),
    ("price","p","last","close","trade_price"),
    ("qty","size","amount","volume","q","quantity","base_volume","quote_volume","vol","v"),
    ("is_buyer_maker","is_buyer_maker_flag","isBuyerMaker","is_buy_maker","buyer_maker","is_maker","maker_flag","side")
]

def _normalize_tick_cols(df: pd.DataFrame) -> pd.DataFrame:
    cols = {c.lower(): c for c in df.columns}
    def pick(cands):
        for c in cands:
            lc = c.lower()
            if lc in cols: return cols[lc]
        return None
    ts = pick(TICK_COL_OPTS[0])
    px = pick(TICK_COL_OPTS[1])
    q  = pick(TICK_COL_OPTS[2])
    ib = pick(TICK_COL_OPTS[3])
    if ts is None or px is None:
        raise ValueError("Tick CSV missing required columns (ts/price).")
    mapping = {ts:"ts", px:"price"}
    if q is not None:
        mapping[q] = "qty"
    out = df.rename(columns=mapping)
    # derive qty if missing
    if "qty" not in out.columns:
        # try quote amount / price
        q_quote = None
        for c in ("quote_qty","quote_volume","amount_q","notional"):
            if c in df.columns:
                q_quote = c; break
        if q_quote is not None:
            out["qty"] = pd.to_numeric(df[q_quote], errors="coerce") / pd.to_numeric(out["price"], errors="coerce")
        else:
            out["qty"] = 1.0
    # normalize side/is_buyer_maker
    if ib is not None:
        if ib.lower() == "side" and ib in df.columns:
            side = df[ib].astype(str).str.upper()
            out["is_buyer_maker"] = (side == "SELL").astype(int)
        else:
            out = out.rename(columns={ib:"is_buyer_maker"})
    # ts to UTC with numeric unit detection if needed
    if not np.issubdtype(out["ts"].dtype, np.datetime64):
        ser = pd.to_numeric(out["ts"], errors="coerce")
        unit = "ms" if float(ser.dropna().median()) > 1e11 else "s"
        out["ts"] = pd.to_datetime(ser, utc=True, errors="coerce", unit=unit)
    return out[["ts","price","qty"] + (["is_buyer_maker"] if "is_buyer_maker" in out.columns else [])]

def find_tick_paths(cfg: dict, cli_ticks_glob: str | None) -> list:
    if cli_ticks_glob:
        paths = sorted(_glob.glob(cli_ticks_glob))
        if paths:
            return paths
    ticks_glob = (cfg.get("files", {}) or {}).get("ticks_glob")
    if ticks_glob:
        paths = sorted(_glob.glob(ticks_glob))
        if paths:
            return paths
    # Fallback auto-detect near ohlcv_glob root
    ohlcv_glob = (cfg.get("files", {}) or {}).get("ohlcv_glob", "")
    ohlcv_paths = _glob.glob(ohlcv_glob)
    root = os.path.commonpath(ohlcv_paths) if ohlcv_paths else "data"
    guess = sorted(_glob.glob(os.path.join(root, "**", "*ticks*.csv"), recursive=True))
    return guess

def read_ticks(paths: list, chunksize: int = 1_000_000) -> pd.DataFrame:
    if not paths:
        return pd.DataFrame(columns=["ts","price","qty","is_buyer_maker"]) 
    parts = []
    used, skipped = 0, 0
    for p in tqdm(paths, desc="Reading ticks", total=len(paths)):
        try:
            df = pd.read_csv(p, low_memory=False)
            df = _normalize_tick_cols(df)
            parts.append(df)
            used += 1
        except Exception as e:
            print(f"[Warn] skip non-tick file: {p} ({e})")
            skipped += 1
    t = pd.concat(parts, ignore_index=True).sort_values("ts")
    if "is_buyer_maker" not in t.columns:
        sgn = np.sign(t["price"].diff().fillna(0.0))
        t["is_buyer_maker"] = (sgn <= 0).astype(int)
    if skipped:
        print(f"[Load] used {used} tick files, skipped {skipped}")
    return t


def load_config(path: str) -> dict:
    import yaml
    return yaml.safe_load(open(path, "r", encoding="utf-8"))


def _expand(path_or_glob: str) -> list:
    if not path_or_glob:
        return []
    if any(ch in path_or_glob for ch in "*?[]"):
        return glob.glob(path_or_glob)
    return [path_or_glob]


def main(cfg_path: str = "configs/event_study.yaml", *, ohlcv_glob: str | None = None, ticks_glob: str | None = None):
    cfg = load_config(cfg_path) if Path(cfg_path).exists() else {}
    study = cfg.get("study", {})
    horizon_min = int(study.get("horizon_min", 180))
    k_list = study.get("k_list", [2.0,3.0,4.0])
    m_list = study.get("m_list", [1.0,1.5])
    don_win = int(study.get("donchian_window", 60))

    files = cfg.get("files", {})
    src_glob = ohlcv_glob or files.get("ohlcv_glob") or files.get("ohlcv") or "data/ticks/BTCUSDT/BTCUSDT-1m-2025-*.csv"
    alerts_csv = files.get("alerts_csv", "results/alerts_used.csv")

    # Minute OHLCV and ATR60
    paths = _expand(src_glob)
    if not paths:
        print(f"[Error] No OHLCV files found for glob: {src_glob}")
        print("Hint: set files.ohlcv_glob in configs/event_study.yaml or pass --ohlcv_glob")
        return
    parts = []
    print(f"[Load] OHLCV: {len(paths)} files matched; reading...")
    for p in tqdm(sorted(set(paths)), desc="Reading OHLCV", total=len(set(paths))):
        try:
            parts.append(read_any_ohlcv(p))
        except Exception as e:
            print(f"[Warn] failed to read OHLCV: {p} ({e})")
    bars = pd.concat(parts, ignore_index=True).sort_values("ts").drop_duplicates(subset=["ts"], keep="last").set_index("ts")
    bars["ATR"] = atr(bars[["open","high","low","close"]], window=60)
    print(f"[Load] OHLCV minutes: {len(bars):,}")

    # Ticks → microbars via discovery
    tick_paths = find_tick_paths(cfg, ticks_glob)
    if not tick_paths:
        print("[Error] No tick CSVs found (files.ticks_glob unset and autodetect empty).")
        print("Set files.ticks_glob to e.g. data/ticks/BTCUSDT/BTCUSDT-ticks-2025-*.csv")
        return
    ticks = read_ticks(tick_paths)
    print(f"[Load] ticks: {len(ticks):,} rows from {len(tick_paths)} files")
    micro_tf = str(cfg.get("absorption", {}).get("micro_tf", "1s"))
    micro = ticks_to_microbars(ticks, micro_tf=micro_tf)
    micro = attach_minute_ATR60_to_micro(micro, bars, bars["ATR"])  # ATR60 proxy

    # Donchian on minute; forward-fill to micro
    d_hi = donchian_high(bars["close"], window=don_win).reindex(micro.index, method="ffill")
    d_lo = donchian_low(bars["close"], window=don_win).reindex(micro.index, method="ffill")

    # Absorption events
    ac = cfg.get("absorption", {})
    a_cfg = AbsorptionCfg(
        lookback_s=int(ac.get("lookback_s", 60)),
        z_delta_thr=float(ac.get("z_delta_thr", 2.5)),
        wick_bias_min=float(ac.get("wick_bias_min", 0.65)),
        donchian_prox_atr=ac.get("donchian_prox_atr", 0.35),
        lambda_drop=bool(ac.get("lambda_drop", True)),
        alpha=float(ac.get("alpha", 1.0)),
    )
    ev = absorption_events(micro, a_cfg, d_hi, d_lo)
    ev = ev.rename(columns={"t_abs":"ts"})
    ev["ts"] = pd.to_datetime(ev["ts"], utc=True)

    # Gates
    if not Path(alerts_csv).exists():
        print(f"[Error] alerts CSV not found at: {alerts_csv}")
        print("Hint: run your bracket to materialize alerts_used.csv or point files.alerts_csv to a CSV with column t_alert")
        return
    alerts = pd.read_csv(alerts_csv)
    alerts["t_alert"] = pd.to_datetime(alerts["t_alert"], utc=True)

    # Filter events inside gates
    def in_gates(ts):
        return ((alerts["t_alert"] <= ts) & (alerts["t_alert"] + pd.Timedelta(minutes=horizon_min) >= ts)).any()
    ev_g = ev[ev["ts"].map(in_gates)].copy()

    # Barrier outcomes (minute-based)
    results = []
    print(f"[Eval] events in gates: {len(ev_g)}; evaluating barriers...")
    for _, r in tqdm(ev_g.iterrows(), total=len(ev_g), desc="Evaluating",):
        start = bars.index[bars.index.searchsorted(r["ts"])]
        if start not in bars.index: continue
        dirn = int(r["direction"])  # +1 or -1
        atr0 = float(bars.loc[start, "ATR"]) if np.isfinite(bars.loc[start, "ATR"]) else np.nan
        if not np.isfinite(atr0) or atr0 <= 0: continue
        w = bars.loc[start : start + pd.Timedelta(minutes=horizon_min)]
        px0 = float(bars.loc[start, "close"])
        for K in k_list:
            for M in m_list:
                hit_tp, hit_sl, t_hit_tp, t_hit_sl = False, False, None, None
                tp_level = px0 + dirn * K * atr0
                sl_level = px0 - dirn * M * atr0
                for ts, br in w.iterrows():
                    hi, lo = float(br["high"]), float(br["low"]) 
                    if (dirn==+1 and hi >= tp_level) or (dirn==-1 and lo <= tp_level):
                        hit_tp, t_hit_tp = True, ts
                        break
                    if (dirn==+1 and lo <= sl_level) or (dirn==-1 and hi >= sl_level):
                        hit_sl, t_hit_sl = True, ts
                        break
                win = bool(hit_tp and not hit_sl)
                tth = (t_hit_tp - start).total_seconds()/60.0 if hit_tp else np.nan
                results.append({"ts": r["ts"], "dir": dirn, "K": float(K), "M": float(M), "win": win, "tth_min": tth})

    res = pd.DataFrame(results)
    outdir = Path("results/study"); outdir.mkdir(parents=True, exist_ok=True)
    ev_g.to_csv(outdir / "absorption_events_in_gates.csv", index=False)
    res.to_csv(outdir / "absorption_barrier_outcomes.csv", index=False)
    summary = res.groupby(["K","M"]).agg(n=("win","size"), p_win=("win","mean"), med_tth=("tth_min","median")).reset_index()
    summary.to_csv(outdir / "absorption_summary.csv", index=False)
    print(summary.to_string(index=False))
    # PASS line
    pass_mask = ((summary["K"]==3.0) & (summary["M"].isin([1.0,1.5])) & (summary["p_win"]>=0.40))
    print("PASS" if pass_mask.any() else "NO-PASS")


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/event_study.yaml")
    ap.add_argument("--ticks_glob", type=str, default=None)
    ap.add_argument("--ohlcv_glob", type=str, default=None)
    args = ap.parse_args()
    main(args.config, ohlcv_glob=args.ohlcv_glob, ticks_glob=args.ticks_glob)
