import pandas as pd
import numpy as np

def ticks_to_microbars(ticks: pd.DataFrame, micro_tf: str = "1s") -> pd.DataFrame:
    """
    ticks: columns must include ts (datetime64[ns, UTC]), price, qty.
    Optional: is_buyer_maker (bool or {0,1}). If missing, infer sign by price change.
    Returns microbars indexed by ts (floored to micro_tf) with:
      open, high, low, close,
      buy_vol, sell_vol, delta,            # delta = buy_vol - sell_vol
      tr                                   # true range = high - low (in microbar)
    """
    t = ticks.copy()
    t = t.sort_values("ts")
    if "is_buyer_maker" not in t.columns:
        sgn = np.sign(t["price"].diff().fillna(0.0))
        # seller if price down or same (maker on sell side)
        t["is_buyer_maker"] = (sgn <= 0).astype(int)
    g = t.groupby(t["ts"].dt.floor(micro_tf))
    o = g["price"].first(); h = g["price"].max(); l = g["price"].min(); c = g["price"].last()
    buy = g.apply(lambda df: df.loc[df["is_buyer_maker"] == 0, "qty"].sum()).astype(float)
    sell = g.apply(lambda df: df.loc[df["is_buyer_maker"] == 1, "qty"].sum()).astype(float)
    df = pd.DataFrame({
        "open": o, "high": h, "low": l, "close": c,
        "buy_vol": buy, "sell_vol": sell
    }).fillna(0.0).sort_index()
    df["delta"] = df["buy_vol"] - df["sell_vol"]
    df["tr"] = (df["high"] - df["low"]).fillna(0.0)
    return df

def attach_minute_ATR60_to_micro(micro: pd.DataFrame, minute_ohlcv: pd.DataFrame, atr_series: pd.Series) -> pd.DataFrame:
    """
    Align 1m ATR60 to microbar index via forward-fill.
    minute_ohlcv indexed by minute ts. atr_series indexed same as minute_ohlcv.
    Output micro with column 'ATR60' aligned.
    """
    atr = atr_series.reindex(minute_ohlcv.index).ffill()
    s = atr.reindex(micro.index, method="ffill")
    out = micro.copy()
    out["ATR60"] = s
    return out

def rolling_z(series: pd.Series, lookback: int) -> pd.Series:
    r = series.rolling(lookback, min_periods=max(5, lookback//3))
    mu = r.mean(); sd = r.std(ddof=1)
    z = (series - mu) / sd.replace({0.0: np.nan})
    return z

def rolling_lambda(micro: pd.DataFrame, lookback: int = 60) -> pd.Series:
    """
    Kyle’s lambda proxy over microbars: cov(Δp, ΔCVD)/var(ΔCVD).
    Here ΔCVD ~ delta (per microbar), Δp ~ price change per microbar.
    """
    dp = micro["close"].diff().fillna(0.0)
    dcvd = micro["delta"].fillna(0.0)
    def _lam(x):
        a = x["dp"].values; b = x["dcvd"].values
        vb = np.var(b, ddof=1)
        if len(a) < 5 or vb == 0.0: return np.nan
        return float(np.cov(a, b, ddof=1)[0,1] / vb)
    tmp = pd.DataFrame({"dp": dp, "dcvd": dcvd})
    lam = tmp.rolling(lookback, min_periods=max(10, lookback//2)).apply(_lam, raw=False)
    return lam

